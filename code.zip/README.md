# ECE.590.07.Sp21-NST

This repository contains the scripts to perform the experiement of neural stylization of traditional asian Ppintings on Duke University buildings. To run the scritps, simply execute the following code. It will generate output directory that contains stylized images and place them into corresponding directories based on the models you are going to explore.

```bash
git clone https://github.com/tienyuliu/ECE.590.07.Sp21-NST.git
cd scripts
python nst_experiment.py
```
